// main.js
//
// Main entry point for ARCGIS_WINDY_INTEGRATION app
//

/**
 * Dynamically import a module and call its init() if available.
 */
async function tryImportModule(path, bus) {
  try {
    const module = await import(path);

    if (module.init && typeof module.init === "function") {
      module.init(bus);
      console.log(`✅ Module initialized: ${path}`);
    } else {
      console.log(`ℹ️ Module imported but no init(): ${path}`);
    }
  } catch (err) {
    console.error(`❌ Failed to load module: ${path}`, err);
  }
}

/**
 * Load all modules from /Modules folder
 */
async function loadModules(bus) {
  const modulePaths = [
    "./Modules/WindyMapandSynchronization.js",
    "./Modules/AddingLayers.js", 
    "./Modules/Notification.js",
    "./Modules/Resizer.js",
    "./Modules/QueryParams.js",
    "./Modules/Logging.js",
    "./Modules/Login.js",
    "./Modules/Importing.js",
    "./Modules/Language.js",
    "./Modules/LayerList.js",
  ];

  for (const path of modulePaths) {
    await tryImportModule(path, bus);
  }
}

/**
 * Application entry point
 */
async function start() {
  console.log("[Main] Starting application...");

  // Create mediator bus
  const bus = new EventTarget();

  // Load all modules
  await loadModules(bus);

  // ✅ Fire app:init so WindyMapandSynchronization.js can start
  console.log("[Main] Dispatching app:init");
  bus.dispatchEvent(new Event("app:init"));
}

// Auto-start when DOM ready
document.addEventListener("DOMContentLoaded", start);
