// Modules/WindyMapandSynchronization.js
//
// Handles Windy API map initialization and synchronization with widgets
// Exports: init(bus)

let windyMap = null; // Windy Leaflet instance
let windyAPI = null; // Windy API object

/**
 * Initialize module from main.js with the app bus
 */
export function init(bus) {
  console.log("[WindyMapSync] Module loaded");

  // Listen for app:init event from main.js
  bus.addEventListener("app:init", () => {
    console.log("[WindyMapSync] app:init received → initializing Windy map");
    initWindy(bus);
  });
}

/**
 * Initialize Windy API and bind to #windy div
 */
function initWindy(bus) {
  if (!window.windyInit) {
    console.error("[WindyMapSync] ❌ windyInit not found! Check libBoot.js");
    return;
  }

  const options = {
    key: "IBNceMmvQwDBMJOwMIucJnl9vE4ViujZ",  // optional, can be empty for free mode
    lat: 50.4,
    lon: 14.3,
    zoom: 5,
    verbose: true
    // container defaults to #windy
  };

  window.windyInit(options, (api) => {

    console.log("[WindyMapSync] ✅ Windy map initialized");


    windyAPI = api;
    windyMap = api.map;
    const { picker, store, broadcast } = windyAPI

    // set up map location 
    const params = new URLSearchParams(window.location.search);

    const lat = params.get("lat");
    const lng = params.get("lng");
    const zoom = params.get("zoom");

    const layerURLs = params.getAll('layerURL');


    if (layerURLs.length) {


      layerURLs.forEach(layerURL => {
        addLayerToMap(layerURL);
      });


    }

    if (location) {

      windyMap.setView([lat, lng], zoom); // =>done 

      // Wait since wather is rendered
      broadcast.once('redrawFinished', () => {
        // Opening of a picker (async)
        picker.open({ lat: lat, lon: lng });

      });


      // L.marker([lat, lng]).addTo(windyMap);
    }



    const iframes = document.querySelectorAll("iframe");
    const overlays = params.getAll("overlay");



    // Set overlay to "pressure"


    if (overlays.length) {
      store.set('overlay', overlays[0]);

      iframes.forEach((iframe, i) => {
        setOverlay(iframe.id, overlays.slice(1)[i]);


      });
    }







    // Example marker
    // L.marker([50.4, 14.3])
    //   .addTo(windyMap)
    //   .bindPopup("Hello from Windy+ArcGIS integration");


    // ✅ Listen for "layer:add" requests from AddingLayers.js
    // bus.addEventListener("layer:add", (e) => {
    //   const { layer } = e.detail;
    //   console.log("[WindyMapSync] Adding layer to map:", layer);

    //   let leafletLayer;
    //   if (layer.type === "Tile" || layer.type === "ArcGISTiledMapServiceLayer") {

    //   } else if (layer.type === "Feature" || layer.type === "ArcGISFeatureLayer") {

    //   } else {
    //     console.warn("[WindyMapSync] ⚠️ Unsupported layer type:", layer.type);
    //   }

    //   // Notify other modules (optional, e.g., for LayerList)
    //   if (leafletLayer) {
    //     bus.dispatchEvent(new CustomEvent("layer:added", {
    //       detail: { layer, leafletLayer }
    //     }));
    //   }
    // });

    // Notify other modules (e.g., AddingLayer, LayerList)
    bus.dispatchEvent(new CustomEvent("map:ready", {
      detail: { map: windyMap, windyAPI: api }
    }));
  });

}

/**
 * Optional helper: expose windyMap
 */
export function getWindyMap() {
  return windyMap;
}

function addLayerToMap(layerURL) {
  fetch(`${layerURL}?f=pjson`)
    .then(response => response.json())
    .then(data => {
      const layerType = data.type; // e.g., "Feature Layer", "Map Service"

      if (layerType === "Feature Layer") {
        addFeatureLayer(layerURL);
      } else if (layerType === "Map Service") {
        addTileLayer(layerURL);
      } else {
        console.warn("Unsupported layer type:", layerType);
      }
    })
    .catch(error => {
      console.error("Error fetching layer info:", error);
    });
}

function addTileLayer(layerURL) {
  leafletLayer = L.tileLayer(layerURL, {
    attribution: "ArcGIS",
  }).addTo(windyMap);
}
function addFeatureLayer(layerURL) {
  leafletLayer = L.esri.featureLayer({
    url: layerURL,
  }).addTo(windyMap);
}
function setOverlay(iframeId, overlay) {
  const iframe = document.getElementById(iframeId);

  if (!iframe) return;

  // Assign back
  iframe.src += '&overlay=' + overlay;

}