// Modules/AddingLayers.js
//
// Handles:
//  - Browse Layers modal
//  - Import Portal/Online layers
//  - Add default layers
//  - Dispatch events for LayerList
//

export function init(bus) {
  console.log("[AddingLayers] Module initialized");

  let portalLayers = [];
  let onlineLayers = [];
  let addedLayers = [];
  let map = null; // will be set once WindyMapandSynchronization dispatches map:ready

  // --- Wait for map from WindyMapandSynchronization.js ---
  bus.addEventListener("map:ready", (e) => {
    map = e.detail.map;
    console.log("[AddingLayers] Map is ready:", map);
  });

  // --- UI Elements (custom modal, since you already have Bootstrap one too) ---
  const modal = document.createElement("div");
  modal.id = "layerModalCustom";
  modal.style.display = "none";
  modal.style.position = "fixed";
  modal.style.top = "10%";
  modal.style.left = "20%";
  modal.style.width = "60%";
  modal.style.height = "70%";
  modal.style.background = "#fff";
  modal.style.border = "1px solid #ccc";
  modal.style.zIndex = "9999";
  modal.style.overflow = "auto";
  modal.innerHTML = `
        <div style="padding: 10px; border-bottom: 1px solid #ddd;">
            <button id="closeLayerModal" style="float:right;">❌</button>
            <h3>Browse Layers</h3>
        </div>
        <div style="padding: 10px;">
            <ul class="tabs list-unstyled d-flex gap-2 mb-2">
                <li><button id="tabPortal" class="btn btn-sm btn-outline-primary">ArcGIS Portal Layers</button></li>
                <li><button id="tabOnline" class="btn btn-sm btn-outline-primary">ArcGIS Online Layers</button></li>
            </ul>
            <div id="portalLayersList" style="display:block;"></div>
            <div id="onlineLayersList" style="display:none;"></div>
        </div>
    `;
  document.body.appendChild(modal);

  // Close button
  modal.querySelector("#closeLayerModal").addEventListener("click", () => {
    modal.style.display = "none";
  });

  // Tab switching
  modal.querySelector("#tabPortal").addEventListener("click", () => {
    modal.querySelector("#portalLayersList").style.display = "block";
    modal.querySelector("#onlineLayersList").style.display = "none";
  });

  modal.querySelector("#tabOnline").addEventListener("click", () => {
    modal.querySelector("#portalLayersList").style.display = "none";
    modal.querySelector("#onlineLayersList").style.display = "block";
  });

  // --- Listen for imported layers from Importing.js ---
  bus.addEventListener("layers:ready", (e) => {
    portalLayers = e.detail.portal || [];
    onlineLayers = e.detail.online || [];
    console.log("[AddingLayers] Received layers:", portalLayers, onlineLayers);
    renderLayerLists();
  });

  // --- Render lists ---
  function renderLayerLists() {
    const portalList = modal.querySelector("#portalLayersList");
    const onlineList = modal.querySelector("#onlineLayersList");

    portalList.innerHTML = "";
    onlineList.innerHTML = "";

    function createLayerCard(layer) {
      const card = document.createElement("div");
      card.className = "col-md-4";

      // ✅ Build thumbnail URL correctly
      const thumbUrl =
        layer.thumbnail ||
        "IconsandImages/MapnNotFound.jpeg";

      card.innerHTML = `
        <div class="card h-100 shadow-sm">
            <img src="${thumbUrl}" class="card-img-top" alt="${layer.title}" style="height: 120px; object-fit: cover;">
            <div class="card-body d-flex flex-column">
                <h6 class="card-title">${layer.title}</h6>
                <p class="card-text text-muted small">${layer.type}</p>
                <button class="btn btn-primary btn-sm mt-auto">Add Layer</button>
            </div>
        </div>
    `;

      card
        .querySelector("button")
        .addEventListener("click", () => addLayerToMap(layer));
      return card;
    }

    // Render portal layers
    const portalRow = document.createElement("div");
    portalRow.className = "row g-3";
    portalLayers.forEach((layer) =>
      portalRow.appendChild(createLayerCard(layer))
    );
    portalList.appendChild(portalRow);

    // Render online layers
    const onlineRow = document.createElement("div");
    onlineRow.className = "row g-3";
    onlineLayers.forEach((layer) =>
      onlineRow.appendChild(createLayerCard(layer))
    );
    onlineList.appendChild(onlineRow);
  }

  // --- Add to map ---
  // function addLayerToMap(layer) {
  //     console.log("[AddingLayers] Requesting to add layer via bus:", layer);
  //     bus.dispatchEvent(new CustomEvent("layer:add", { detail: { layer } }));

  // }



  // --- Add a default layer programmatically ---
  function addDefaultLayer(title, url, type = "Tile") {
    const defaultLayer = { title, url, type };
    addLayerToMap(defaultLayer);
  }

  // --- Event API ---
  // bus.addEventListener("layers:browse", (e) => {
  //   modal.style.display = "block";

  // });

  bus.addEventListener("layers:addDefault", (e) => {
    const { title, url, type } = e.detail;
    addDefaultLayer(title, url, type);
  });

  // --- Hook Browse Layers button (UI button in index.html) ---
  const browseBtn = document.getElementById("browse-layers");
  if (browseBtn) {
    browseBtn.addEventListener("click", () => {
      console.log("[AddingLayers] Browse button clicked");
      modal.style.display = "block";
    });
  }
}
