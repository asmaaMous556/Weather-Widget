// Importing.js
//
// Responsible for retrieving ArcGIS layers from portal + ArcGIS Online
//

let portalToken = null;
let portalUrl = null;
let portalUser = null;

// Internal caches
let portalLayers = [];
let onlineLayers = [];

// ✅ Supported keywords
const SUPPORTED_TYPES = [
  "feature layer",
  "feature service",
  "tiled map service",
  "tile service",
  "tile layer",
  "map image layer",
  "image service",
  "image map service",
  "map service",
  "dynamic map service",
  "mapserver",
  "featureserver",
];

/**
 * Checks if an item is supported
 */
function isSupportedLayer(item) {
  if (!item) return false;

  const type = (item.type || "").toLowerCase();
  const url = (item.url || "").toLowerCase();

  return SUPPORTED_TYPES.some((t) => type.includes(t) || url.includes(t));
}
/**
 * Fetch full item details if needed (to get thumbnail, etc.)
 */
async function fetchItemDetails(itemId, source) {
  let baseUrl = source === "portal" ? portalUrl : "https://www.arcgis.com";
  const url = `${baseUrl}/sharing/rest/content/items/${itemId}?f=json&token=${
    portalToken || ""
  }`;

  try {
    const resp = await fetch(url);
    const data = await resp.json();
    return data;
  } catch (err) {
    console.error("[Importing] Failed to fetch item details:", err);
    return null;
  }
}

/**
 * Normalize an item into our layer object
 */
/**
 * Normalize an item into our layer object
 */
/**
 * Normalize an item into our layer object
 */
/**
 * Normalize an item into our layer object (async because we may need to fetch details)
 */
async function toLayer(item, source) {
  if (!isSupportedLayer(item)) return null;

  let thumbnail = item.thumbnail || null;

  // If no thumbnail, try fetching details
  if (!thumbnail) {
    let baseUrl = source === "portal" ? portalUrl : "https://www.arcgis.com";
    const url = `${baseUrl}/sharing/rest/content/items/${
      item.id
    }?f=json&token=${portalToken || ""}`;

    try {
      const resp = await fetch(url);
      const details = await resp.json();
      if (details && details.thumbnail) {
        thumbnail = details.thumbnail;
      }
    } catch (err) {
      console.error("[Importing] Failed to fetch item details:", err);
    }
  }

  return {
    id: item.id,
    title: item.title,
    type: item.type,
    url: item.url || null,
    source,
    thumbnail: thumbnail
      ? source === "portal"
        ? `${portalUrl}/sharing/rest/content/items/${item.id}/info/${thumbnail}?token=${portalToken}`
        : `https://www.arcgis.com/sharing/rest/content/items/${item.id}/info/${thumbnail}`
      : null,
  };
}

/**
 * Fetch a folder's items
 */
async function fetchFolderItems(username, folderId = "") {
  const url = `${portalUrl}/sharing/rest/content/users/${username}/${folderId}?f=json&token=${portalToken}`;
  console.log("[Importing] Fetching folder content:", url);

  const resp = await fetch(url);
  const data = await resp.json();

  if (data.error) {
    console.error("[Importing] Error fetching folder:", data.error.message);
    return [];
  }

  const layers = [];
  if (data.items) {
    for (const item of data.items) {
      const layer = await toLayer(item, "portal");
      if (layer) layers.push(layer);
    }
  }

  return layers;
}

/**
 * Fetch all portal layers (root + folders)
 */
async function fetchPortalLayers() {
  let layers = [];

  // Root content
  layers.push(...(await fetchFolderItems(portalUser, "")));

  // Folders
  const foldersUrl = `${portalUrl}/sharing/rest/content/users/${portalUser}?f=json&token=${portalToken}`;
  const resp = await fetch(foldersUrl);
  const data = await resp.json();

  if (data.folders) {
    for (const folder of data.folders) {
      const folderLayers = await fetchFolderItems(portalUser, folder.id);
      layers.push(...folderLayers);
    }
  }

  return layers;
}

/**
 * Fetch ArcGIS Online layers
 */
async function fetchOnlineLayers() {
  const url = `https://www.arcgis.com/sharing/rest/search?q=type:("Feature Service" OR "Map Service" OR "Image Service" OR "Tiled Map Service")&f=json`;
  console.log("[Importing] Fetching ArcGIS Online layers:", url);

  const resp = await fetch(url);
  const data = await resp.json();

  if (data.error) {
    console.error(
      "[Importing] Error fetching online layers:",
      data.error.message
    );
    return [];
  }

  const layers = [];
  if (data.results) {
    for (const item of data.results) {
      const layer = await toLayer(item, "online");
      if (layer) layers.push(layer);
    }
  }

  return layers;
}

/**
 * Initialize Importing module
 */
export function init(bus) {
  console.log("[Importing] Module initialized");

  bus.addEventListener("login:success", async (e) => {
    portalToken = e.detail.token;
    portalUrl = e.detail.portalUrl;
    portalUser = e.detail.username;

    console.log(`[Importing] ✅ Logged in as ${portalUser}`);

    // Fetch both lists
    portalLayers = await fetchPortalLayers();
    onlineLayers = await fetchOnlineLayers();

    console.log("[Importing] ✅ Portal layers:", portalLayers);
    console.log("[Importing] ✅ Online layers:", onlineLayers);

    bus.dispatchEvent(
      new CustomEvent("layers:ready", {
        detail: { portal: portalLayers, online: onlineLayers },
      })
    );
  });
}
