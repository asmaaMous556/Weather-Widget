// Modules/Login.js
//
// Handles ArcGIS Portal login with max 3 tries
//

export function init(bus) {
  console.log("[Login] Module initialized");

  const portalInput = document.getElementById("portal-url");
  const usernameInput = document.getElementById("portal-username");
  const passwordInput = document.getElementById("portal-password");
  const loginBtn = document.getElementById("login-btn");

  if (!portalInput || !usernameInput || !passwordInput || !loginBtn) {
    console.error("[Login] Login form not found in DOM");
    return;
  }

  let attempts = 0;

  loginBtn.addEventListener("click", async () => {
    const portalUrl = portalInput.value.trim();
    const username = usernameInput.value.trim();
    const password = passwordInput.value.trim();

    if (!portalUrl || !username || !password) {
      alert("⚠️ Please fill in all fields");
      return;
    }

    if (attempts >= 3) {
      alert("❌ Too many failed login attempts");
      return;
    }

    try {
      console.log(`[Login] Attempting login to ${portalUrl}...`);

      const tokenUrl = `${portalUrl}/sharing/rest/generateToken`;
      const params = new URLSearchParams({
        username,
        password,
        f: "json",
        client: "referer",
        referer: window.location.origin,
        expiration: 60
      });

      const response = await fetch(tokenUrl, {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: params
      });

      const data = await response.json();

      if (data.error) {
        attempts++;
        alert(`❌ Login failed (${attempts}/3): ${data.error.message}`);
        return;
      }

      const token = data.token;
      console.log("[Login] ✅ Token generated:", token);

      // Broadcast to other modules
      bus.dispatchEvent(
        new CustomEvent("login:success", {
          detail: { portalUrl, username, token }
        })
      );

      alert(`✅ Logged in as ${username}`);
    } catch (err) {
      attempts++;
      console.error("[Login] Error:", err);
      alert(`❌ Login failed (${attempts}/3). Check console.`);
    }
  });
}
